/**
 * 
 */

var modalBtn = document.querySelector('.addbutton');
   var modalBg = document.querySelector('.modal-bg');
   var modalClose = document.querySelector('.modalclose');
   var modalClose1 = document.querySelector('.close') 

   modalBtn.addEventListener('click',function(){
       modalBg.classList.add('bg-active');
   });
   modalClose.addEventListener('click',function(){
    modalBg.classList.remove('bg-active');

   });
   modalClose1.addEventListener('click',function(){
    modalBg.classList.remove('bg-active');

   });



   var modalBtn1 = document.querySelector('.editbutton');
   var modalBg1 = document.querySelector('.modal-bg1');
   var modalClose1 = document.querySelector('.modalclose1');
   var modalClose2 = document.querySelector('.close1') 
   modalBtn1.addEventListener('click',function(){
       modalBg1.classList.add('bg-active1');
   });
   modalClose1.addEventListener('click',function(){
    modalBg1.classList.remove('bg-active1');

   });
   modalClose2.addEventListener('click',function(){
    modalBg1.classList.remove('bg-active1');

   });


   var modalBtn2 = document.querySelector('.Delbutton');
   var modalBg2 = document.querySelector('.modal-bg2');
   var modalClose3 = document.querySelector('.modalclose2');
   var modalClose4 = document.querySelector('.cancel') 
   modalBtn2.addEventListener('click',function(){
       modalBg2.classList.add('bg-active2');
   });
   modalClose3.addEventListener('click',function(){
    modalBg2.classList.remove('bg-active2');

   });
   modalClose4.addEventListener('click',function(){
    modalBg2.classList.remove('bg-active2');

   });
   
   
   fetch("http://localhost:8080/H2HBABBA1074/dummy.do").then(
		    res =>{
		        res.json().then(
		            data =>
		            {
		                console.log(data);
		                if(data.length>0){
		                    var temp = "";

		                    data.forEach((u) =>{
		                        temp +="<tr>";
		                        temp += "<td>"+u.Customer_Name+"</td>";
		                        temp += "<td>"+u.Customer_no+"</td>";
		                        temp += "<td>"+u.Due_Date+"</td>";
		                        temp += "<td>"+u.Invoice_id+"</td>";
		                        temp += "<td>"+u.Invoice_Amount+"</td>";
		                        temp += "<td>"+u.Predicated_Payment_Date+"</td>";
		                        temp += "<td>"+u.Notes+"</td></tr>"; 
		                    });

		                    document.getElementById("data").innerHTML = temp;
		                    
		                    
		                }
		            });
		    });
   
   