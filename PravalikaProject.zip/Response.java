package com.higradius;

import java.util.Date;

public class Response {
	private String Customer_Name;
	private Integer Customer_no;
	private Date Due_Date;
	private Integer Invoice_id;
	private Integer Invoice_Amount;
	private Date Predicated_Payment_Date;
	private String Notes;
	
	public String getCustomer_Name() {
		return Customer_Name;
	}
	public void setCustomer_Name(String Customer_Name) {
		this.Customer_Name = Customer_Name;
	}
	public Integer getCustomer_no() {
		return Customer_no;
	}
	public void setCustomer_no(Integer Customer_no) {
		this.Customer_no = Customer_no;
	}
	public Date getDue_Date() {
		return Due_Date;
	}
	public void setDue_Date(Date Due_Date) {
		this.Due_Date = Due_Date;
	}
	public Integer getInvoice_id() {
		return Invoice_id;
	}
	public void setInvoice_id(Integer Invoice_id) {
		this.Invoice_id = Invoice_id;
	}
	public Integer getInvoice_Amount() {
		return Invoice_Amount;
	}
	public void setInvoice_Amount(Integer Invoice_Amount) {
		this.Invoice_Amount = Invoice_Amount;
	}
	public Date getPredicated_Payment_Date() {
		return Predicated_Payment_Date;
	}
	public void setPredicated_Payment_Date(Date Predicated_Payment_Date) {
		this.Predicated_Payment_Date = Predicated_Payment_Date;
	}
	public String getNotes() {
		return Notes;
	}
	public void setNotes(String Notes) {
		this.Notes = Notes;
	
	}
}
