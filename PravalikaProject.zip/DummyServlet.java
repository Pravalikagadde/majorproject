package com.higradius;

import java.io.IOException;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;


/**
 * Servlet implementation class dummyServlet
 */
@WebServlet("/dummyServlet")
public class DummyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static final String JDBC_DRIVER  = "com.mysql.jdbc.Driver";
	static final String DB_URL = "jdbc:mysql://localhost:3306/suram";
	
	private static final String USER  = "root";
	private static final String PASSWORD  = "pravalika9@";
	
	
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DummyServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		response.getWriter().append("Served at: ").append(request.getContextPath());
		Connection conn = null;
		Statement stmt = null;
		String sql = null;
		Integer sql1 = null;
		ResultSet rs = null;
		String Customer_Name = null;
		Integer Customer_no = null;
		Integer Invoice_id = null;
		Integer Invoice_Amount = null;
		Date Due_Date = null;
		Date Predicated_Payment_Date = null;
		String Notes = null;
		List<Response> responseList = new ArrayList<>();
		
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection(DB_URL,USER,PASSWORD);
			stmt = conn.createStatement(); 
			sql = "select Customer_no,Customer_Name,Invoice_id,Due_Date,Invoice_Amount,Predicated_Payment_Date,Notes from suram3";
			rs = stmt.executeQuery(sql);
			while(rs.next()) {
				Response pojoresponse = new Response();
				Customer_Name = rs.getString(2);
				Customer_no = rs.getInt(1);
				Invoice_id = rs.getInt(3);
				Invoice_Amount = rs.getInt(5);
				Due_Date = rs.getDate(4);
				Predicated_Payment_Date = rs.getDate(6);
				Notes = rs.getString(7);
				pojoresponse.setCustomer_Name(Customer_Name);
				pojoresponse.setCustomer_no(Customer_no);
				pojoresponse.setInvoice_id(Invoice_id);
				pojoresponse.setInvoice_Amount(Invoice_Amount);
				pojoresponse.setDue_Date(Due_Date);
				pojoresponse.setPredicated_Payment_Date(Predicated_Payment_Date);
				pojoresponse.setNotes(Notes);
				responseList.add(pojoresponse);
				
				}
			    Gson gson = new GsonBuilder().setPrettyPrinting().create();
			    String json = gson.toJson(responseList);
			    System.out.print(json);
			    response.setContentType("application/json");
			    response.getWriter().write(json);
			
			
			
		}catch(Exception ex)
		{
			ex.printStackTrace();
			
		}
		
		
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	
}


